# AI Dictionary v1.0 — Windows 11 x64 Uninstaller
$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\AI Dictionary"
Remove-Item -Path "$Home\Desktop\AI Dictionary.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item -Path "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\AI Dictionary.lnk" -Force -ErrorAction SilentlyContinue
if (Test-Path $InstallDir) {
    Remove-Item -Path $InstallDir -Recurse -Force
}
Write-Host "[OK] AI Dictionary has been completely uninstalled." -ForegroundColor Yellow
