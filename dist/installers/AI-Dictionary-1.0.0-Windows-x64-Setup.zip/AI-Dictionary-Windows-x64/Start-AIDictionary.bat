@echo off
chcp 65001 >nul
title AI Dictionary — Local Offline AI Dictionary (Resident System Tray)
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0app\scripts\windows_tray_shell.ps1"
