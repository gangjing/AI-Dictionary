# AI Dictionary v1.0 — Windows 11 x64 Automated Installer
$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\AI Dictionary"
Write-Host "[AI Dictionary] Installing to $InstallDir ..." -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item -Path "$PSScriptRoot\*" -Destination $InstallDir -Recurse -Force

$WshShell = New-Object -ComObject WScript.Shell
$DesktopShortcut = $WshShell.CreateShortcut("$Home\Desktop\AI Dictionary.lnk")
$DesktopShortcut.TargetPath = "$InstallDir\Start-AIDictionary.bat"
$DesktopShortcut.IconLocation = "$InstallDir\app\icon.ico"
$DesktopShortcut.WorkingDirectory = $InstallDir
$DesktopShortcut.Save()

$StartMenuDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
$StartShortcut = $WshShell.CreateShortcut("$StartMenuDir\AI Dictionary.lnk")
$StartShortcut.TargetPath = "$InstallDir\Start-AIDictionary.bat"
$StartShortcut.IconLocation = "$InstallDir\app\icon.ico"
$StartShortcut.WorkingDirectory = $InstallDir
$StartShortcut.Save()

Write-Host "[OK] AI Dictionary v1.0 installed successfully! Desktop & Start Menu shortcuts created." -ForegroundColor Green
