; AI Dictionary v1.0 — NSIS Windows x64 Installer Script
!define APP_NAME "AI Dictionary"
!define APP_VERSION "1.0.0"
OutFile "AI-Dictionary-1.0.0-Windows-x64-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\AI Dictionary"
Icon "app\icon.ico"
RequestExecutionLevel user
Section "Install"
  SetOutPath "$INSTDIR"
  File /r "*.*"
  CreateShortCut "$DESKTOP\AI Dictionary.lnk" "$INSTDIR\Start-AIDictionary.bat" "" "$INSTDIR\app\icon.ico"
  CreateShortCut "$SMPROGRAMS\AI Dictionary.lnk" "$INSTDIR\Start-AIDictionary.bat" "" "$INSTDIR\app\icon.ico"
SectionEnd
